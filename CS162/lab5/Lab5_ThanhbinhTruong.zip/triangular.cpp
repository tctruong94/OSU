#include<iostream>

using namespace std;


/****************************************
**Name:triangular
**Description: calculates and returns the triangular number for N
****************************************/
int triangular(int n)
{
    return n * (n+1) / 2;
}