#ifndef MATRIX_HPP
#define MATRIX_HPP

#include <string>
#include <iostream>
#include "Determinant.hpp"

void readMatrix(int**, int);

#endif