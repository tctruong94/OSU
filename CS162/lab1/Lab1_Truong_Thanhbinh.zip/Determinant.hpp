#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

#include <string>
#include <iostream>

int determinant(int**, int);

#endif